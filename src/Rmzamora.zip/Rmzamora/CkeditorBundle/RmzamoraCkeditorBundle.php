<?php

namespace Rmzamora\CkeditorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RmzamoraCkeditorBundle extends Bundle
{
}
